<hr>
<div>
  <p>
    &#169; PHP Motors, All Rights Reserved.<br>
    All images used are believed to be in "Fair Use". Please notify the author if they are not and they will be removed.
  </p>
</div>